package androidx.coordinatorlayout;
/* loaded from: classes.dex */
public final class R {

    /* loaded from: classes.dex */
    public static final class attr {
        public static int alpha = 0x7f04002e;
        public static int coordinatorLayoutStyle = 0x7f040149;
        public static int font = 0x7f0401fa;
        public static int fontProviderAuthority = 0x7f0401fc;
        public static int fontProviderCerts = 0x7f0401fd;
        public static int fontProviderFetchStrategy = 0x7f0401fe;
        public static int fontProviderFetchTimeout = 0x7f0401ff;
        public static int fontProviderPackage = 0x7f040200;
        public static int fontProviderQuery = 0x7f040201;
        public static int fontStyle = 0x7f040203;
        public static int fontVariationSettings = 0x7f040204;
        public static int fontWeight = 0x7f040205;
        public static int keylines = 0x7f040261;
        public static int layout_anchor = 0x7f04026d;
        public static int layout_anchorGravity = 0x7f04026e;
        public static int layout_behavior = 0x7f04026f;
        public static int layout_dodgeInsetEdges = 0x7f0402a0;
        public static int layout_insetEdge = 0x7f0402aa;
        public static int layout_keyline = 0x7f0402ab;
        public static int statusBarBackground = 0x7f0403f0;
        public static int ttcIndex = 0x7f0404b5;

        private attr() {
        }
    }

    /* loaded from: classes.dex */
    public static final class color {
        public static int notification_action_color_filter = 0x7f0602ce;
        public static int notification_icon_bg_color = 0x7f0602cf;
        public static int ripple_material_light = 0x7f0602d9;
        public static int secondary_text_default_material_light = 0x7f0602db;

        private color() {
        }
    }

    /* loaded from: classes.dex */
    public static final class dimen {
        public static int compat_button_inset_horizontal_material = 0x7f070056;
        public static int compat_button_inset_vertical_material = 0x7f070057;
        public static int compat_button_padding_horizontal_material = 0x7f070058;
        public static int compat_button_padding_vertical_material = 0x7f070059;
        public static int compat_control_corner_material = 0x7f07005a;
        public static int compat_notification_large_icon_max_height = 0x7f07005b;
        public static int compat_notification_large_icon_max_width = 0x7f07005c;
        public static int notification_action_icon_size = 0x7f070304;
        public static int notification_action_text_size = 0x7f070305;
        public static int notification_big_circle_margin = 0x7f070306;
        public static int notification_content_margin_start = 0x7f070307;
        public static int notification_large_icon_height = 0x7f070308;
        public static int notification_large_icon_width = 0x7f070309;
        public static int notification_main_column_padding_top = 0x7f07030a;
        public static int notification_media_narrow_margin = 0x7f07030b;
        public static int notification_right_icon_size = 0x7f07030c;
        public static int notification_right_side_padding_top = 0x7f07030d;
        public static int notification_small_icon_background_padding = 0x7f07030e;
        public static int notification_small_icon_size_as_large = 0x7f07030f;
        public static int notification_subtext_size = 0x7f070310;
        public static int notification_top_pad = 0x7f070311;
        public static int notification_top_pad_large_text = 0x7f070312;

        private dimen() {
        }
    }

    /* loaded from: classes.dex */
    public static final class drawable {
        public static int notification_action_background = 0x7f0800d1;
        public static int notification_bg = 0x7f0800d2;
        public static int notification_bg_low = 0x7f0800d3;
        public static int notification_bg_low_normal = 0x7f0800d4;
        public static int notification_bg_low_pressed = 0x7f0800d5;
        public static int notification_bg_normal = 0x7f0800d6;
        public static int notification_bg_normal_pressed = 0x7f0800d7;
        public static int notification_icon_background = 0x7f0800d8;
        public static int notification_template_icon_bg = 0x7f0800d9;
        public static int notification_template_icon_low_bg = 0x7f0800da;
        public static int notification_tile_bg = 0x7f0800db;
        public static int notify_panel_notification_icon_bg = 0x7f0800dc;

        private drawable() {
        }
    }

    /* loaded from: classes.dex */
    public static final class id {
        public static int accessibility_action_clickable_span = 0x7f09000f;
        public static int accessibility_custom_action_0 = 0x7f090010;
        public static int accessibility_custom_action_1 = 0x7f090011;
        public static int accessibility_custom_action_10 = 0x7f090012;
        public static int accessibility_custom_action_11 = 0x7f090013;
        public static int accessibility_custom_action_12 = 0x7f090014;
        public static int accessibility_custom_action_13 = 0x7f090015;
        public static int accessibility_custom_action_14 = 0x7f090016;
        public static int accessibility_custom_action_15 = 0x7f090017;
        public static int accessibility_custom_action_16 = 0x7f090018;
        public static int accessibility_custom_action_17 = 0x7f090019;
        public static int accessibility_custom_action_18 = 0x7f09001a;
        public static int accessibility_custom_action_19 = 0x7f09001b;
        public static int accessibility_custom_action_2 = 0x7f09001c;
        public static int accessibility_custom_action_20 = 0x7f09001d;
        public static int accessibility_custom_action_21 = 0x7f09001e;
        public static int accessibility_custom_action_22 = 0x7f09001f;
        public static int accessibility_custom_action_23 = 0x7f090020;
        public static int accessibility_custom_action_24 = 0x7f090021;
        public static int accessibility_custom_action_25 = 0x7f090022;
        public static int accessibility_custom_action_26 = 0x7f090023;
        public static int accessibility_custom_action_27 = 0x7f090024;
        public static int accessibility_custom_action_28 = 0x7f090025;
        public static int accessibility_custom_action_29 = 0x7f090026;
        public static int accessibility_custom_action_3 = 0x7f090027;
        public static int accessibility_custom_action_30 = 0x7f090028;
        public static int accessibility_custom_action_31 = 0x7f090029;
        public static int accessibility_custom_action_4 = 0x7f09002a;
        public static int accessibility_custom_action_5 = 0x7f09002b;
        public static int accessibility_custom_action_6 = 0x7f09002c;
        public static int accessibility_custom_action_7 = 0x7f09002d;
        public static int accessibility_custom_action_8 = 0x7f09002e;
        public static int accessibility_custom_action_9 = 0x7f09002f;
        public static int action_container = 0x7f09003a;
        public static int action_divider = 0x7f09003c;
        public static int action_image = 0x7f09003d;
        public static int action_text = 0x7f090043;
        public static int actions = 0x7f090044;
        public static int async = 0x7f090052;
        public static int blocking = 0x7f09005c;
        public static int bottom = 0x7f09005d;
        public static int chronometer = 0x7f090071;
        public static int dialog_button = 0x7f090095;
        public static int end = 0x7f0900ae;
        public static int forever = 0x7f0900c2;
        public static int icon = 0x7f0900d4;
        public static int icon_group = 0x7f0900d5;
        public static int info = 0x7f0900dd;
        public static int italic = 0x7f0900e0;
        public static int left = 0x7f0900e6;
        public static int line1 = 0x7f0900e9;
        public static int line3 = 0x7f0900ea;
        public static int none = 0x7f090137;
        public static int normal = 0x7f090138;
        public static int notification_background = 0x7f09013a;
        public static int notification_main_column = 0x7f09013b;
        public static int notification_main_column_container = 0x7f09013c;
        public static int right = 0x7f090167;
        public static int right_icon = 0x7f090169;
        public static int right_side = 0x7f09016a;
        public static int start = 0x7f09019f;
        public static int tag_accessibility_actions = 0x7f0901ab;
        public static int tag_accessibility_clickable_spans = 0x7f0901ac;
        public static int tag_accessibility_heading = 0x7f0901ad;
        public static int tag_accessibility_pane_title = 0x7f0901ae;
        public static int tag_screen_reader_focusable = 0x7f0901b2;
        public static int tag_transition_group = 0x7f0901b4;
        public static int tag_unhandled_key_event_manager = 0x7f0901b5;
        public static int tag_unhandled_key_listeners = 0x7f0901b6;
        public static int text = 0x7f0901b8;
        public static int text2 = 0x7f0901b9;
        public static int time = 0x7f0901c8;
        public static int title = 0x7f0901c9;
        public static int top = 0x7f0901cd;

        private id() {
        }
    }

    /* loaded from: classes.dex */
    public static final class integer {
        public static int status_bar_notification_info_maxnum = 0x7f0a0043;

        private integer() {
        }
    }

    /* loaded from: classes.dex */
    public static final class layout {
        public static int custom_dialog = 0x7f0c001d;
        public static int notification_action = 0x7f0c0060;
        public static int notification_action_tombstone = 0x7f0c0061;
        public static int notification_template_custom_big = 0x7f0c0062;
        public static int notification_template_icon_group = 0x7f0c0063;
        public static int notification_template_part_chronometer = 0x7f0c0064;
        public static int notification_template_part_time = 0x7f0c0065;

        private layout() {
        }
    }

    /* loaded from: classes.dex */
    public static final class string {
        public static int status_bar_notification_info_overflow = 0x7f10009f;

        private string() {
        }
    }

    /* loaded from: classes.dex */
    public static final class style {
        public static int TextAppearance_Compat_Notification = 0x7f1101c4;
        public static int TextAppearance_Compat_Notification_Info = 0x7f1101c5;
        public static int TextAppearance_Compat_Notification_Line2 = 0x7f1101c6;
        public static int TextAppearance_Compat_Notification_Time = 0x7f1101c7;
        public static int TextAppearance_Compat_Notification_Title = 0x7f1101c8;
        public static int Widget_Compat_NotificationActionContainer = 0x7f11032e;
        public static int Widget_Compat_NotificationActionText = 0x7f11032f;
        public static int Widget_Support_CoordinatorLayout = 0x7f11045c;

        private style() {
        }
    }

    /* loaded from: classes.dex */
    public static final class styleable {
        public static int ColorStateListItem_alpha = 0x00000003;
        public static int ColorStateListItem_android_alpha = 0x00000001;
        public static int ColorStateListItem_android_color = 0x00000000;
        public static int ColorStateListItem_android_lStar = 0x00000002;
        public static int ColorStateListItem_lStar = 0x00000004;
        public static int CoordinatorLayout_Layout_android_layout_gravity = 0x00000000;
        public static int CoordinatorLayout_Layout_layout_anchor = 0x00000001;
        public static int CoordinatorLayout_Layout_layout_anchorGravity = 0x00000002;
        public static int CoordinatorLayout_Layout_layout_behavior = 0x00000003;
        public static int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 0x00000004;
        public static int CoordinatorLayout_Layout_layout_insetEdge = 0x00000005;
        public static int CoordinatorLayout_Layout_layout_keyline = 0x00000006;
        public static int CoordinatorLayout_keylines = 0x00000000;
        public static int CoordinatorLayout_statusBarBackground = 0x00000001;
        public static int FontFamilyFont_android_font = 0x00000000;
        public static int FontFamilyFont_android_fontStyle = 0x00000002;
        public static int FontFamilyFont_android_fontVariationSettings = 0x00000004;
        public static int FontFamilyFont_android_fontWeight = 0x00000001;
        public static int FontFamilyFont_android_ttcIndex = 0x00000003;
        public static int FontFamilyFont_font = 0x00000005;
        public static int FontFamilyFont_fontStyle = 0x00000006;
        public static int FontFamilyFont_fontVariationSettings = 0x00000007;
        public static int FontFamilyFont_fontWeight = 0x00000008;
        public static int FontFamilyFont_ttcIndex = 0x00000009;
        public static int FontFamily_fontProviderAuthority = 0x00000000;
        public static int FontFamily_fontProviderCerts = 0x00000001;
        public static int FontFamily_fontProviderFetchStrategy = 0x00000002;
        public static int FontFamily_fontProviderFetchTimeout = 0x00000003;
        public static int FontFamily_fontProviderPackage = 0x00000004;
        public static int FontFamily_fontProviderQuery = 0x00000005;
        public static int FontFamily_fontProviderSystemFontFamily = 0x00000006;
        public static int GradientColorItem_android_color = 0x00000000;
        public static int GradientColorItem_android_offset = 0x00000001;
        public static int GradientColor_android_centerColor = 0x00000007;
        public static int GradientColor_android_centerX = 0x00000003;
        public static int GradientColor_android_centerY = 0x00000004;
        public static int GradientColor_android_endColor = 0x00000001;
        public static int GradientColor_android_endX = 0x0000000a;
        public static int GradientColor_android_endY = 0x0000000b;
        public static int GradientColor_android_gradientRadius = 0x00000005;
        public static int GradientColor_android_startColor = 0x00000000;
        public static int GradientColor_android_startX = 0x00000008;
        public static int GradientColor_android_startY = 0x00000009;
        public static int GradientColor_android_tileMode = 0x00000006;
        public static int GradientColor_android_type = 0x00000002;
        public static int[] ColorStateListItem = {16843173, 16843551, 16844359, com.TBOX.R.attr.alpha, com.TBOX.R.attr.lStar};
        public static int[] CoordinatorLayout = {com.TBOX.R.attr.keylines, com.TBOX.R.attr.statusBarBackground};
        public static int[] CoordinatorLayout_Layout = {16842931, com.TBOX.R.attr.layout_anchor, com.TBOX.R.attr.layout_anchorGravity, com.TBOX.R.attr.layout_behavior, com.TBOX.R.attr.layout_dodgeInsetEdges, com.TBOX.R.attr.layout_insetEdge, com.TBOX.R.attr.layout_keyline};
        public static int[] FontFamily = {com.TBOX.R.attr.fontProviderAuthority, com.TBOX.R.attr.fontProviderCerts, com.TBOX.R.attr.fontProviderFetchStrategy, com.TBOX.R.attr.fontProviderFetchTimeout, com.TBOX.R.attr.fontProviderPackage, com.TBOX.R.attr.fontProviderQuery, com.TBOX.R.attr.fontProviderSystemFontFamily};
        public static int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, com.TBOX.R.attr.font, com.TBOX.R.attr.fontStyle, com.TBOX.R.attr.fontVariationSettings, com.TBOX.R.attr.fontWeight, com.TBOX.R.attr.ttcIndex};
        public static int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static int[] GradientColorItem = {16843173, 16844052};

        private styleable() {
        }
    }

    private R() {
    }
}
