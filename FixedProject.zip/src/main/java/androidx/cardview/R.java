package androidx.cardview;
/* loaded from: classes.dex */
public final class R {

    /* loaded from: classes.dex */
    public static final class attr {
        public static int cardBackgroundColor = 0x7f04009a;
        public static int cardCornerRadius = 0x7f04009b;
        public static int cardElevation = 0x7f04009c;
        public static int cardMaxElevation = 0x7f04009e;
        public static int cardPreventCornerOverlap = 0x7f04009f;
        public static int cardUseCompatPadding = 0x7f0400a0;
        public static int cardViewStyle = 0x7f0400a1;
        public static int contentPadding = 0x7f04013f;
        public static int contentPaddingBottom = 0x7f040140;
        public static int contentPaddingLeft = 0x7f040142;
        public static int contentPaddingRight = 0x7f040143;
        public static int contentPaddingTop = 0x7f040145;

        private attr() {
        }
    }

    /* loaded from: classes.dex */
    public static final class color {
        public static int cardview_dark_background = 0x7f06002a;
        public static int cardview_light_background = 0x7f06002b;
        public static int cardview_shadow_end_color = 0x7f06002c;
        public static int cardview_shadow_start_color = 0x7f06002d;

        private color() {
        }
    }

    /* loaded from: classes.dex */
    public static final class dimen {
        public static int cardview_compat_inset_shadow = 0x7f070052;
        public static int cardview_default_elevation = 0x7f070053;
        public static int cardview_default_radius = 0x7f070054;

        private dimen() {
        }
    }

    /* loaded from: classes.dex */
    public static final class style {
        public static int Base_CardView = 0x7f110010;
        public static int CardView = 0x7f110120;
        public static int CardView_Dark = 0x7f110121;
        public static int CardView_Light = 0x7f110122;

        private style() {
        }
    }

    /* loaded from: classes.dex */
    public static final class styleable {
        public static int[] CardView = {16843071, 16843072, com.TBOX.R.attr.cardBackgroundColor, com.TBOX.R.attr.cardCornerRadius, com.TBOX.R.attr.cardElevation, com.TBOX.R.attr.cardMaxElevation, com.TBOX.R.attr.cardPreventCornerOverlap, com.TBOX.R.attr.cardUseCompatPadding, com.TBOX.R.attr.contentPadding, com.TBOX.R.attr.contentPaddingBottom, com.TBOX.R.attr.contentPaddingLeft, com.TBOX.R.attr.contentPaddingRight, com.TBOX.R.attr.contentPaddingTop};
        public static int CardView_android_minHeight = 0x00000001;
        public static int CardView_android_minWidth = 0x00000000;
        public static int CardView_cardBackgroundColor = 0x00000002;
        public static int CardView_cardCornerRadius = 0x00000003;
        public static int CardView_cardElevation = 0x00000004;
        public static int CardView_cardMaxElevation = 0x00000005;
        public static int CardView_cardPreventCornerOverlap = 0x00000006;
        public static int CardView_cardUseCompatPadding = 0x00000007;
        public static int CardView_contentPadding = 0x00000008;
        public static int CardView_contentPaddingBottom = 0x00000009;
        public static int CardView_contentPaddingLeft = 0x0000000a;
        public static int CardView_contentPaddingRight = 0x0000000b;
        public static int CardView_contentPaddingTop = 0x0000000c;

        private styleable() {
        }
    }

    private R() {
    }
}
